<template>
    <div>
        <div class="web">
            <div class="header">
            <menubar/>
        </div>
        <div class="wrap">
            <div class="container">
                <img class="logoimg" src="https://github.com/siaoliu66/Shiba-Dinn/blob/gh-pages/image/logo.png?raw=true" alt="">
                <label for="price">商品金額</label>
                <input type="number" class="form price" id="price" placeholder="請輸入日幣金額" v-model.number="price">
                <label for="shipping">日本境內運費</label>
                <input type="number" class="form shipping" id="shipping" placeholder="請輸入日本境內運費,無運費請填0"  v-model.number="shipping">
                <label for="num">預估重量</label>
                <input type="number" class="form num" id="num" placeholder="請輸入預估重量(公斤)" v-model.number="num">
                <button @click="cal()">計算價格</button>
            </div>
                <hr>
               <div class="text" id="text" v-if="totalPrice">
                <p>📣報價如下</p>
                <p v-if="shipping==0">🔷商品金額：<span class="Price">{{price | toCurrency}}</span> * 0.270 = <span class="totalPrice">{{totalPrice | toCurrency}}</span></p>
                <p v-else>🔷商品金額：[<span class="Price">{{price | toCurrency}}</span> + <span class="Shipping">{{shipping | toCurrency}}</span>(日本境內運費)]* 0.270 = <span class="totalPrice">{{totalPrice | toCurrency}}</span></p>
                <p>🔷國際運費：1公斤250元<br>
                <p>🔷應付金額：<span class="totalPrice">{{totalPrice | toCurrency}}</span> + <span class="Num">250*{{num | toCurrency}}</span>(重量預估1kg以內) + 60(超商運費) = <span class="finalPrice">{{finalPrice | toCurrency}}</span></p>
                </div>
                <div class="copy" v-if="totalPrice">
                <button data-clipboard-target="#text" ref="copy" data-clipboard-action="copy" @click="copyLink">點擊複製</button>
                </div>
        </div>
        </div>

    </div>
</template>

<style lang="scss" scoped>
    body {
  height: 100vh;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
}
.web{
    padding-top: 25px;
}
.wrap {
  max-width: 588px;
  padding: 15px;
  width: 100%;
  margin: auto;
  background-color: #006973;
  color: #ffd68c;    
  margin-top: 64px;
}

.wrap .header {
  text-align: center;
}

.wrap .header img {
  width: 200px;
}

.wrap .container {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
      -ms-flex-direction: column;
          flex-direction: column;
}
.wrap .container .logoimg{
    width: 200px;
    margin: 0 auto;
}
.wrap .container label {
  margin: 5px;
  font-size: 1rem;
}

.wrap .container .form {
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
}

.wrap .container .input-group {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: stretch;
      -ms-flex-align: stretch;
          align-items: stretch;
  width: 100%;
  margin-top: 10px;
}

.wrap .container .info {
  color: #495057;
  margin-left: 5px;
}

.wrap .container button {
  width: 120px;
  height: 35px;
  font-size: 1rem;
  border-radius: 25px;
  margin: 5px auto;
  border: 0;
  background-color: white;
  margin-top: 15px;
}
/*手機板*/
@media screen and (max-width: 414px) {
  body {
    height: auto;
  }
}
</style>

<script>
import menubar from "./topmenu";
import alert from "../alertMesseges";


// import $ from "jquery";
export default {
  components: {
    menubar,alert
  },
  data(){
    return {
      price: '',
      shipping:'',
      num:'',
      totalPrice:'',
      finalPrice :'',
      copyBtn: null
    }
  },
  methods:{
      cal(){
      const vm = this
      vm.totalPrice = Math.round((vm.price + vm.shipping) * 270/1000)
      vm.finalPrice = Math.round(vm.totalPrice + vm.num * 250 + 60)
    },
    copyLink() {      
      const vm = this;
        const clipboard = vm.copyBtn;
        clipboard.on('success', function() {
          vm.$bus.$emit('message:push',"複製成功",'success')
        });
        clipboard.on('error', function() {
          vm.$bus.$emit('message:push',"複製失敗，請手動選擇複製！",'warning')
        });   
      }, 
    }, 
    filters:{
      toCurrency(num){
        var parts = num.toString().split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return parts.join('.');
      }
    },
    mounted() {    
      this.copyBtn = new this.clipboard(this.$refs.copy);
    },
};
</script>
