'use strict'
module.exports = {
  NODE_ENV: '"production"',
  APIPATH: '"https://vue-course-api.hexschool.io"',
  APIID: '"shibadinn"',
}
